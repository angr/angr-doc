import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.lang.reflect.Field;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NotFun {
	static {
		System.loadLibrary("notfun");
	}

	private native static long getUnicornLocation(String s);
	private native static long getUnicornColor(long a);
	private native static void kill(long addr, int bb);
	private native static int magic000(int n1);
	private native static int magic0(int n1);
	private native static int magic1(int n1);
	private native static int magic2(int n1);
	private native static int magic3(int n1);
	private native static int magic4(int n1);
	private native static int magic5(int n1);
	private native static int magic6(int n1);
	private native static int magic7(int n1);
	private native static int magic8(int n1);
	private native static int magic9(int n1);	

	private static int MAX_FILE_TIME = 30*60*1000;
	private static int MAX_FILE_NUMBER = 25000;

	private String UnicornMaster = "UnicornMaster";
	private String PoorUnicorn = "PoorUnicorn";
	private boolean unicornKilled = false;
	BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

	private String publicKey = "c0f3c2e0d35facffd5b78ea4447fac106c0976696aca375849192e2b5422bec0d382b83c53c2fe6aefd13e093ae03817dcfb280e18e41258b949863633fec9082500e73987ecfd562e36754c45319b160febca7fdd9aebe175dfd19f9610fa77b20d10fcf4437464969634a82d3d7a698c0ae0d96bfdb531dca6ad31e032c6c202c8f512da5725f76bf0d8fca0b37c6ff7b54e7de6a684de64bac60fd8cbb34a00a234893880bdb4ed0d76145226f64cc88c0306543811c38ad3f75bfd9a07186ef08786eec35674dd7aa521b36f7f621482054caba235dbae154bcba58cafb95e3accca1fb49059191c274c6639a6abffea78db00be7192cf960150f57e9c1b";
	private String exponent = "10001";

	public int getInt(){
		try {
			return Integer.valueOf(reader.readLine());
		} catch (NumberFormatException e) {
			System.exit(1);
		} catch (IOException e) {
			System.exit(1);
		}
		return 0;
	}
	public long getLong(){
		try {
			return Long.valueOf(reader.readLine());
		} catch (NumberFormatException e) {
			System.exit(1);
		} catch (IOException e) {
			System.exit(1);
		}
		return 0;
	}
	public String getString(){
		try {
			String r = reader.readLine();
			if(r==null){
				System.exit(1);
			}
			return r;
		} catch (IOException e) {
			System.exit(1);
		}
		return "";
	}
	public long getStartingPoint(){
		String ss = getString();

		try{
			long ll = Long.valueOf(ss);
			return ll;
		}catch (NumberFormatException e) {
			Class cc = this.getClass();
			try {
				Field ff = cc.getDeclaredField(ss);
				ff.setAccessible(true);
				String ssValue = (String) ff.get(this);
				long um = getUnicornLocation(ssValue);
				um &= 0xfffffffffff00000L;
				return um;
			} catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e1) {
				return 0;
			}

		} 
	}
	public void print(Object ss){
		String str;
		if(!(ss instanceof String)){
			str = String.valueOf(ss);
		}else{
			str = (String) ss;
		}
		System.out.println(str);
	}

	public NotFun() {
		;
	}

	public static void main(String[] args) {
		cleanup();
		NotFun game = new NotFun();
		game.run();
	}

	private static void cleanup() {
		long now = new Date().getTime();
		File folder = new File(".");
		File[] foundFiles = folder.listFiles();
		if(foundFiles.length <= MAX_FILE_NUMBER){
			return;
		}

		for(File f : foundFiles){
			long lm = f.lastModified();
			if(lm == 0){
				continue;
			}
			//System.err.println(f.getName() + " " + String.valueOf(f.lastModified()));
			if(f.lastModified() < now - MAX_FILE_TIME){
				//System.err.println("deleting " + f.getName() + " " + String.valueOf(f.lastModified()));
				f.delete();
			}
		}
	}
	private void run() {
		print("Welcome! Unicorns are not having fun here... I hope you will not have fun too.");
		while(true){
			if(! mainMenu()){
				break;
			}
		}
		print("Unicorns are still not having fun and I don't see any rainbow. Do you like dolphins?");
	}

	private boolean mainMenu(){
		print("1) Play versus AI");
		print("2) Read score");
		print("3) Exit");
		int choice = getInt();
		switch(choice){
		case 1:
			gameMenu();
			break;
		case 2:
			readScoreMenu();
			break;
		case 3:
			return false;
		case 0:
			connectToAI();
			break;
		}
		return true;		
	}

	private void gameFail(){
		print("AI won!");
		System.exit(11);
	}
	private void game(){
		for(int i=0; i<5; i++){
			Random rnd = new Random();
			int c1,c2,c3,c4,c5;
			c1 = rnd.nextInt(100);
			c2 = rnd.nextInt(100);
			c3 = rnd.nextInt(256);
			c4 = rnd.nextInt(10);
			c5 = rnd.nextInt(10);
			print("These are your unlucky numbers:");
			print(c1);
			print(c2);
			print(c3);
			c3 <<= 8;

			switch(c4){
			case 0:
				c3 = c3 * 2 + 3;
				break;
			case 1:
				c3 = c3 * 7 + 8;
				break;
			case 2:
				c3 = c3 * 3 + 1;
				break;
			case 3:
				c3 = c3 * 5 + 3;
				break;
			case 4:
				c3 = c3 * 2 + 9;
				break;
			case 5:
				c3 = c3 * 9 + 1;
				break;
			case 6:
				c3 = c3 * 6 + 2;
				break;
			case 7:
				c3 = c3 * 5 + 4;
				break;
			case 8:
				c3 = c3 * 8 + 2;
				break;
			case 9:
				c3 = c3 * 4 + 2;
				break;
			}
			switch(c5){
			case 0:
				c3 = magic0(c3);
				break;
			case 1:
				c3 = magic1(c3);
				break;
			case 2:
				c3 = magic2(c3);
				break;
			case 3:
				c3 = magic3(c3);
				break;
			case 4:
				c3 = magic4(c3);
				break;
			case 5:
				c3 = magic5(c3);
				break;
			case 6:
				c3 = magic6(c3);
				break;
			case 7:
				c3 = magic7(c3);
				break;
			case 8:
				c3 = magic8(c3);
				break;
			case 9:
				c3 = magic9(c3);
				break;
			}
			print(c4);
			print(c5);

			//System.err.println("expected: " + String.valueOf(c1+2)+"|"+String.valueOf(c2*3+1)+"|"+String.valueOf(c3));
			if(! (getInt() == c1 + 2)){
				gameFail();
			}
			if(! (getInt() == magic000(c2))){
				gameFail();
			}
			if(! (getInt() == c3)){
				gameFail();
			}
		}
		print("You won!");
	}

	private void gameMenu() {
		long t1 = new Date().getTime();
		game();
		long t2 = new Date().getTime();
		long score = ((1000*1000) - (t2-t1));
		print("Your score is: " + String.valueOf(score));

		print("Choose price:");
		print("1) Write score");
		print("2) Kill a unicorn");
		int c = getInt();
		switch(c){
		case 1:
			writeScore(score);
			break;
		case 2:
			killUnicornMenu();
			break;
		default:
			print("Wrong choice");
			System.exit(2);
		}
	}

	private void printScore(String filename){
		try {
			File file = new File(filename);
			Scanner sc = new Scanner(file);
			print("This is your comment:");
			print(sc.nextLine());
			print("This is your score:");
			print(sc.nextLine());
			sc.close();
		} catch (FileNotFoundException e) {
			print("I cannot find your file, I think you don't know the password!");
			System.exit(4);
		}
	}

	private void readScoreMenu() {
		print("give me your name:");
		String name = getString();
		if(! checkValidStringFile(name)){
			print("wrong name!");
			System.exit(3);
		}
		print("give me your password:");
		String password = getString();
		if(! checkValidStringFile(password)){
			print("wrong password!");
			System.exit(3);
		}
		printScore(name+"_"+password);
	}

	private void writeScore(long score){
		print("give me your name:");
		String name = getString();
		if(! checkValidStringFile(name)){
			print("wrong name!");
			System.exit(3);
		}
		print("give me your password:");
		String password = getString();
		if(! checkValidStringFile(password)){
			print("wrong password!");
			System.exit(3);
		}
		print("give me your comment:");
		String comment = getString();
		if(! checkValidString(comment)){
			print("wrong comment!");
			System.exit(3);
		}

		try {
			PrintWriter out = new PrintWriter(name+"_"+password);
			out.println(comment);
			out.print(String.valueOf(score));
			out.close();
		} catch (FileNotFoundException e) {
			System.exit(10);
		}
	}
	
	private void connectToAI() {
		SecureRandom rnd = new SecureRandom();
		BigInteger challenge = new BigInteger(2047, rnd);
		print("I want an unicorn of this color:");
		print(String.valueOf(challenge));
		String answer = getString();
		BigInteger challenge2 = new BigInteger(answer,16).modPow(new BigInteger(exponent,16), new BigInteger(publicKey,16));
		if(challenge.equals(challenge2)){
			print("I like you.");
			godMode();
		}else{
			print("You are not smart enough for this AI: hack harder or use more CPUs!");
		}
	}
	
	private void godMode() {
		print("come se fosse?");
		final String flag_id = getString();
		if(! checkValidStringFile(flag_id)){
			print("wrong name!");
			System.exit(3);
		}

		File folder = new File(".");
		File[] foundFiles = folder.listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) {
				return name.startsWith(flag_id);
			}
		});
		printScore(foundFiles[0].getName());
	}
	
	private void killUnicornMenu(){
		print("Give me the color of the unicorn you want to kill:");
		long unicornColor = getLong();
		print("Where should I start?");
		long um = getStartingPoint();
		print("How do you want to kill the unicorn?");
		int killMethod = getInt();
		if(unicornKilled){
			print("Come on! You cannot kill too many unicorns.");
			System.exit(5);
		}
		
		//13511005043687473 <-- 0x30003000300031
		int i = 0;
		int t = 0;
		while(true){
			long v = getUnicornColor(um+i);
			if(t==killMethod/8){
				break;
			}
			if(v==unicornColor){
				kill(um+i, killMethod%8);
				print("AI found and killed the unicorn. You should feel bad.");
				unicornKilled = true;
				//print(i); print(exponent);
				t+=1;
			}
			i+=1;
			if(i>10000000){
				break;
			}
		}
	}
	
	private boolean checkValidStringFile(String str){
		Pattern pattern = Pattern.compile("[0-9a-zA-Z]{3,20}");
		Matcher matcher = pattern.matcher(str);
		if(matcher.matches()){
			return true;
		}else{
			return false;
		}
	}
	
	private boolean checkValidString(String str){
		Pattern pattern = Pattern.compile("[0-9a-zA-Z !_,:]{1,100}");
		Matcher matcher = pattern.matcher(str);
		if(matcher.matches()){
			return true;
		}else{
			return false;
		}
	}

}